import React, {useState} from 'react';




const AddEmployee = (props) => {

    const [newEmployee, addNewEmployee] = useState("");
    
    const handleChange = (e) => {
        addNewEmployee(e.target.value);
    }

    const handleClick = () => {
        props.addEmployeeToArray(newEmployee);
    }
    return(
        <section>
            <h3>Legg til ny ansatt</h3>
            <label>Navn:</label>
            <input onChange={handleChange} type="text"></input>
            <input onClick={handleClick} type="button" value="Legg til ansatt"></input>
            <p>{props.employees.length}</p>
        </section>
    )
}

export default AddEmployee;
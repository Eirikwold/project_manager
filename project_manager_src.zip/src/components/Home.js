import React from 'react';

import AddEmployee from './subcomponents/AddEmployee';

export const Home = () => {
    return(
        <div>
            <AddEmployee/>
            
        </div>
    )
}

   